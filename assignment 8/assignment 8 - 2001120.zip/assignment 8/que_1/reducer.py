#!/usr/bin/env python3
"""reducer.py"""

import sys


if __name__=="__main__":
    
    words = set()
    for line in sys.stdin:
        line=line.strip().split()
        for w in line:
            words.add(w)
    
    words = sorted(words)
    for word in words:
        print(word)


