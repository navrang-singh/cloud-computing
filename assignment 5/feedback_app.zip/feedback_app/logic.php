<?php 

$sql = "create table if not exists user_data(
    userid int(3) unsigned auto_increment primary key,
    username varchar(30) not null,
    password varchar(10) not null,
    first_name varchar(30) not null,
    last_name varchar(30),
    contact_no varchar(10),
    email varchar(20),
    root_user int(1)
)";
$conn->query($sql);


$sql = "create table if not exists complaints_data(
    id int(3) unsigned auto_increment primary key,
    userid int(3) unsigned,
    complaint_header varchar(1000),
    complaint_body varchar(10000),
    foreign key (userid) references user_data(userid)
)";
$conn->query($sql);

function user_validation(&$conn, $username, $password){
	$sql = "select * from user_data where username='".$username."' and password='".$password."'";
    $result = $conn->query($sql);
    if(mysqli_num_rows($result) > 0){
    	$row = $result->fetch_assoc();
    	return array(
            'root_user' => $row['root_user'], 
            'userid' => $row['userid']
        );
    }else{
    	return FALSE;
    }
}

function create_new_user(&$conn,$username, $password,$first_name,$last_name,$contact_no,$email, $root_user=1){
    $sql = "INSERT INTO user_data (username, password,first_name,last_name,contact_no,email,root_user) VALUES ('".$username."', '".$password."','".$first_name."','".$last_name."','".$contact_no."','".$email."','".$root_user."')";
    if($conn->query($sql) === TRUE){
        return TRUE;
    }else{
        die("Could not able to create user error : ".$conn->erorr);
    }
}


function push_complaint(&$conn, $userid, $complaint_header, $complaint_body){
    $sql = "INSERT INTO complaints_data(userid, complaint_header, complaint_body) VALUES ('".$userid."', '".$complaint_header."', '".$complaint_body."')";
    if($conn->query($sql) === TRUE){
        return TRUE;
    }else{
        die("Could not able to resister complaint :".$conn->error);
    }
}


function fetch_complaint(&$conn, $userid=0){
    $sql="";
    if($userid == 0){
        $sql = "select c.id, c.complaint_header, c.complaint_body, u.username  from complaints_data as c, user_data as u where c.userid=u.userid";
    }else{
        $sql = "select c.id, c.complaint_header, c.complaint_body, u.username from complaints_data as c, user_data as u where c.userid=u.userid and c.userid='".$userid."'";
    }
    $result = $conn->query($sql);
    $toReturn = array();
    while($row = $result->fetch_assoc()){
        $element = array(
            'id' => $row['id'],
            'complaint_header' => $row['complaint_header'], 
            'complaint_body' => $row['complaint_body'], 
            'username' => $row['username'],
            'userid' => $userid
        );
        array_push($toReturn, json_encode($element));
    }

    return $toReturn;
}

function fetch_complaint_by_id(&$conn, $cid){
    $sql = "select c.id, u.username, c.complaint_header, c.complaint_body FROM complaints_data as c, user_data as u WHERE c.userid=u.userid and c.id='".$cid."'";
    $result = $conn->query($sql);
    $toReturn = array();
    while($row = $result->fetch_assoc()){
        $element = array(
            'id' => $row['id'],
            'complaint_header' => $row['complaint_header'], 
            'complaint_body' => $row['complaint_body'],
            'username' => $row['username']
        );
        array_push($toReturn, json_encode($element));
    }

    return $toReturn[0];
}

?>
