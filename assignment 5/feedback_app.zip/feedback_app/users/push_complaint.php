<?php
include '../configuration.php';
include '../logic.php';

session_start();
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$header = mysqli_escape_string($conn, $_POST['header']);
	$body = mysqli_escape_string($conn, $_POST['body']);
	$userid = $_SESSION['userid'];

	$user = push_complaint($conn, $userid, $header, $body);
	if($user){
		header('location: user_complaints.php');
	}else{
		header('location: user_complaints.php?msg="error occured"');
	}
}else{
	header('location: ../index.php');
}

?>