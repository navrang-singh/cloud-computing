#!/usr/bin/env python
"""mapper.py"""

import sys 


if __name__=="__main__":
    
    for line in sys.stdin: 
        line = line.strip() 
        words = line.split() 
        for word in words: 
            print(f'{word},1')