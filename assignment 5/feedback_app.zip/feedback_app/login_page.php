<?php
include 'configuration.php';
include 'logic.php';

session_start();
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$username = mysqli_escape_string($conn, $_POST['username']);
	$password = mysqli_escape_string($conn, $_POST['password']);

	$user = user_validation($conn, $username, $password);
	if($user !==FALSE){
		$_SESSION['userid'] = $user['userid'];
		$_SESSION['username'] = $username;
		$_SESSION['root_user'] = $user['root_user'];

		if($_SESSION['root_user'] == 1){
			header('location: users/user_complaints.php');
		}else{
			header('location: admin_user/all_complaints.php'); 
		}
	}else{
		header('location: index.php?msg="Invalid login credentials."');
	}
}else{
	header('location: index.php');
}

?>