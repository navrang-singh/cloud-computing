#!/usr/bin/env python
"""mapper.py"""

import sys

if __name__=="__main__":
    punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
    n_puc=""
    for line in sys.stdin:
        for char in line:
            if char not in punctuations:
                n_puc+=char

    n_puc=n_puc.lower()

    print(n_puc)

