#!/usr/bin/env python
"""mapper.py"""

import numpy as np
import pandas as pd
import math
import warnings
warnings.filterwarnings('ignore')

if __name__=="__main__":
    column=['sepal_length', 'sepal_width', 'petal_length', 'petal_width', 'class']
    data=pd.read_csv('iris.csv',names=column)

    irs = [5.8, 4.0, 1.2, 0.2, 'Iris-setosa']
    irv = [6.1,2.8,4.0,1.3, 'Iris-versicolor']
    irvi = [6.3,2.7,4.9,1.8, 'Iris-virginica']

    for j in range(100):
        for  i in range(len(data)):
            i1 = data.iloc[i]
            v1 = math.sqrt((irs[0] - i1[0])**2 + (irs[1] - i1[1])**2)
            v2 = math.sqrt((irv[0] - i1[0])**2 + (irv[1] - i1[1])**2)
            v3 = math.sqrt((irvi[0] - i1[0])**2 + (irvi[1] - i1[1])**2)
            if((v1 <= v2 and v2 <= v3) or (v1 <= v3 and v3 <= v2)):
                data.iloc[i][4] = 'Iris-setosa'
            elif((v2<=v1 and v1 <= v3) or (v2 <= v3 and v3 <= v1)):
                data.iloc[i][4] = 'Iris-versicolor'
            elif((v3 <= v1 and v1 <= v2) or (v3 <= v2 and v2 <= v1)):
                data.iloc[i][4] = 'Iris-virginica'
        
        irs = data[data['class'] == 'Iris-setosa']
        irs_t = irs.mean(axis=0)
        irs=[irs_t[0],irs_t[1],irs_t[2],irs_t[3],'Iris-setosa']
        irv = data[data['class'] == 'Iris-versicolor']
        irv_t = irv.mean(axis=0)
        irv=[irv_t[0],irv_t[1],irv_t[2],irv_t[3],'Iris-versicolor']
        irvi = data[data['class'] == 'Iris-virginica']
        irvi_t = irvi.mean(axis=0)
        irvi=[irvi_t[0],irvi_t[1],irvi_t[2],irvi_t[3],'Iris-virginica']

    d = {}
    for i in range(len(data)):
        d[i,data.iloc[i][4]] = 1
        
    for i in d:
        print(i[1],",1")